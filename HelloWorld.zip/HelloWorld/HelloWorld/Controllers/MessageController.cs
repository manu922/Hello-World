﻿using HelloWorld.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HelloWorld.Controllers
{
    [RoutePrefix("api/message")]
    public class MessageController : ApiController
    {
        private readonly IMessageRepository _iMessageRepo;
        public MessageController() { }
        public MessageController(IMessageRepository iMessageRepo)
        {
            this._iMessageRepo = iMessageRepo;
        }

        [HttpGet]
        [Route("show/{writeTo}/{message}")]
        public IHttpActionResult WriteMessage([FromUri]string writeTo, [FromUri] string message)
        {
            MessageResponse response = null;
            if (this._iMessageRepo != null)
            {
                response = this._iMessageRepo.WriteMessage(writeTo, message);
            }

            return Ok(response);
        }
    }
}

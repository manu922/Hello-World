﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorld.Models
{
    public class MessageResponse
    {
        public MessageResponse()
        {
            this.result = new MessageResult();
        }
        public MessageResult result { get; set; }
    }
    public class MessageResult
    {
        public MessageResult() { }
        public bool status { get; set; }
        public string message { get; set; }
    }
}
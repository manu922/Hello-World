﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace HelloWorld.Models
{
    public class MessageRepository : IMessageRepository
    {
        MessageResponse IMessageRepository.WriteMessage(string sourceType, string message)
        {
            bool flag = false;
            SourceTypes _sourceType;
            Enum.TryParse<SourceTypes>(sourceType, true, out _sourceType);
            switch (_sourceType)
            {
                case SourceTypes.Console:
                    Boolean.TryParse(ConfigurationManager.AppSettings["writeToConsole"], out flag);
                    break;
                case SourceTypes.Web:
                    Boolean.TryParse(ConfigurationManager.AppSettings["writeToWeb"], out flag);
                    break;
                case SourceTypes.Text:
                    Boolean.TryParse(ConfigurationManager.AppSettings["writeToText"], out flag);
                    break;
                case SourceTypes.Database:
                    Boolean.TryParse(ConfigurationManager.AppSettings["writeToDB"], out flag);
                    break;
                default:
                    break;
            }
            MessageResponse response = new MessageResponse();
            response.result = new MessageResult();
            response.result.status = flag;
            response.result.message = message;
            return response;
        }
    }
}
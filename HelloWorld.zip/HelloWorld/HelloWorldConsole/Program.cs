﻿using HelloWorld.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldConsole
{
    class Program
    {
        static HttpClient httpClient = new HttpClient();
        static string baseURL = ConfigurationManager.AppSettings["baseapiURL"];
        static string writeMessageURL = ConfigurationManager.AppSettings["writeMessageURL"];
        static void Main(string[] args)
        {
            try
            {
                invokeWriteMessageAPI();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void invokeWriteMessageAPI()
        {
            httpClient.BaseAddress = new Uri(baseURL);
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            writeMessage().Wait();
        }

        static async Task writeMessage()
        {
            using (httpClient)
            {
                HttpResponseMessage response = await httpClient.GetAsync(writeMessageURL);
                if (response != null && response.IsSuccessStatusCode)
                {
                    printResponse(await response.Content.ReadAsAsync<MessageResponse>());
                }
            }
        }
        static void printResponse(MessageResponse messageResponse)
        {
            Console.WriteLine("webapi url:" + baseURL + writeMessageURL);
            Console.WriteLine("status from webapi:" + messageResponse.result.status);
            Console.WriteLine("Message from webapi:" + messageResponse.result.message);
            Console.Read();
        }
    }
}

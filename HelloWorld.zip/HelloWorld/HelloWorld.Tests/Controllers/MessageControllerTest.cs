﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorld.Controllers;
using HelloWorld.Models;
using Moq;
using System.Web.Http;
using System.Web.Http.Results;

namespace HelloWorld.Tests.Controllers
{
    [TestClass]
    public class MessageControllerTest
    {
        [TestMethod]
        public void TestWrieMessage()
        {
            // Arrange
            Mock<IMessageRepository> mockRepository = new Mock<IMessageRepository>();
            MessageResponse messageResponse = new MessageResponse();
            messageResponse.result = new MessageResult() { message = "Hello World", status = true };
            mockRepository.Setup(x => x.WriteMessage("console", "Hello World"))
                .Returns(messageResponse);
            MessageController controller = new MessageController(mockRepository.Object);

            // Act
            IHttpActionResult actionResult = controller.WriteMessage(writeTo: "console", message: "Hello World");
            OkNegotiatedContentResult<MessageResponse> contentResult = actionResult as OkNegotiatedContentResult<MessageResponse>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(true, contentResult.Content.result.status);
            Assert.AreEqual("Hello World", contentResult.Content.result.message);

        }
    }
}
